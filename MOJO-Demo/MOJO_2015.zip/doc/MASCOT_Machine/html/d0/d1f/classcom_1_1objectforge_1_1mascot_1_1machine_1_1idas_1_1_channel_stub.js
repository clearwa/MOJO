var classcom_1_1objectforge_1_1mascot_1_1machine_1_1idas_1_1_channel_stub =
[
    [ "read", "d0/d1f/classcom_1_1objectforge_1_1mascot_1_1machine_1_1idas_1_1_channel_stub.html#a3e7da265c53703c0bcc2781feca14bae", null ],
    [ "status", "d0/d1f/classcom_1_1objectforge_1_1mascot_1_1machine_1_1idas_1_1_channel_stub.html#af69d995717869d8d5fcce55b9c5b21b3", null ],
    [ "write", "d0/d1f/classcom_1_1objectforge_1_1mascot_1_1machine_1_1idas_1_1_channel_stub.html#abbbc012e4cc24ddd1addf88bb47e44d9", null ]
];