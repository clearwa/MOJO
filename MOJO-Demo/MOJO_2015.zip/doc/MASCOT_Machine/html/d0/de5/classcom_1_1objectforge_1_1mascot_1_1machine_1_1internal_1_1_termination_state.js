var classcom_1_1objectforge_1_1mascot_1_1machine_1_1internal_1_1_termination_state =
[
    [ "TerminationState", "d0/de5/classcom_1_1objectforge_1_1mascot_1_1machine_1_1internal_1_1_termination_state.html#a91b3552592b3263914f041f707eb6890", null ],
    [ "getDead", "d0/de5/classcom_1_1objectforge_1_1mascot_1_1machine_1_1internal_1_1_termination_state.html#a7b8325c2b73574750d45bf136076a60e", null ],
    [ "getSuspend", "d0/de5/classcom_1_1objectforge_1_1mascot_1_1machine_1_1internal_1_1_termination_state.html#a3793a9a645f0c98039dde2aff2085ec0", null ],
    [ "isKill", "d0/de5/classcom_1_1objectforge_1_1mascot_1_1machine_1_1internal_1_1_termination_state.html#a5d57aeb2175aa96063bd6be02470a68a", null ],
    [ "isResume", "d0/de5/classcom_1_1objectforge_1_1mascot_1_1machine_1_1internal_1_1_termination_state.html#aca89e6b28a4ae8849c5d4af6cf1458e4", null ],
    [ "isSuspend", "d0/de5/classcom_1_1objectforge_1_1mascot_1_1machine_1_1internal_1_1_termination_state.html#a24c255f373b9f3103dbc2f521596821c", null ],
    [ "dead", "d0/de5/classcom_1_1objectforge_1_1mascot_1_1machine_1_1internal_1_1_termination_state.html#aaf27ae3e7e1f80873ec00a97f95151c9", null ],
    [ "suspend", "d0/de5/classcom_1_1objectforge_1_1mascot_1_1machine_1_1internal_1_1_termination_state.html#af5cf5d871d5ceeafe0b653e6aa902466", null ]
];