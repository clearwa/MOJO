var interfacecom_1_1objectforge_1_1mascot_1_1machine_1_1scheduler_1_1_i_mascot_transaction =
[
    [ "kernel", "d0/dee/interfacecom_1_1objectforge_1_1mascot_1_1machine_1_1scheduler_1_1_i_mascot_transaction.html#a7a313aeb4401ef09861987a8194777b8", null ]
];