var classcom_1_1objectforge_1_1mascot_1_1_i_d_a_1_1telnet_1_1_client_descriptor =
[
    [ "ClientDescriptor", "d0/d25/classcom_1_1objectforge_1_1mascot_1_1_i_d_a_1_1telnet_1_1_client_descriptor.html#a4edb656a248ab867eba1fa50b77461ca", null ],
    [ "ClientDescriptor", "d0/d25/classcom_1_1objectforge_1_1mascot_1_1_i_d_a_1_1telnet_1_1_client_descriptor.html#a6550f0b6f566572d6cc7a5308f0ac793", null ],
    [ "getAddress", "d0/d25/classcom_1_1objectforge_1_1mascot_1_1_i_d_a_1_1telnet_1_1_client_descriptor.html#af54ba436318e2304835fb4e66ef62bf7", null ],
    [ "getConnection", "d0/d25/classcom_1_1objectforge_1_1mascot_1_1_i_d_a_1_1telnet_1_1_client_descriptor.html#afeedb8997e806f0157630c7300134d52", null ],
    [ "getException", "d0/d25/classcom_1_1objectforge_1_1mascot_1_1_i_d_a_1_1telnet_1_1_client_descriptor.html#aafb6eaf57a16ce550a61c17ee9299fbb", null ],
    [ "getPort", "d0/d25/classcom_1_1objectforge_1_1mascot_1_1_i_d_a_1_1telnet_1_1_client_descriptor.html#ab717c477a1f3ac1fd73078d723fc3876", null ],
    [ "getQue", "d0/d25/classcom_1_1objectforge_1_1mascot_1_1_i_d_a_1_1telnet_1_1_client_descriptor.html#a2aa21be672dd096d1f4633681caf475f", null ],
    [ "getSocket", "d0/d25/classcom_1_1objectforge_1_1mascot_1_1_i_d_a_1_1telnet_1_1_client_descriptor.html#a0477e75150b763d921e77ebf27aa7410", null ],
    [ "hasException", "d0/d25/classcom_1_1objectforge_1_1mascot_1_1_i_d_a_1_1telnet_1_1_client_descriptor.html#ade60df596ed81f8e9ec5f63630ca50cd", null ],
    [ "setConnection", "d0/d25/classcom_1_1objectforge_1_1mascot_1_1_i_d_a_1_1telnet_1_1_client_descriptor.html#afd0009e1be52d57cb32c28d0bb0d94b5", null ],
    [ "setException", "d0/d25/classcom_1_1objectforge_1_1mascot_1_1_i_d_a_1_1telnet_1_1_client_descriptor.html#ad1300a9aafce77cf853459f3403b54b2", null ],
    [ "setSocket", "d0/d25/classcom_1_1objectforge_1_1mascot_1_1_i_d_a_1_1telnet_1_1_client_descriptor.html#a0e76b2bbd5ce33df390779ed382e8a2a", null ],
    [ "address", "d0/d25/classcom_1_1objectforge_1_1mascot_1_1_i_d_a_1_1telnet_1_1_client_descriptor.html#aac231af8a55e0a97ff09ccd9c9cb5f61", null ],
    [ "connection", "d0/d25/classcom_1_1objectforge_1_1mascot_1_1_i_d_a_1_1telnet_1_1_client_descriptor.html#a0878ba3c81cf6a8425d63fa06238d53c", null ],
    [ "exception", "d0/d25/classcom_1_1objectforge_1_1mascot_1_1_i_d_a_1_1telnet_1_1_client_descriptor.html#a434e41e8fed7f26b459dadad0630a2bc", null ],
    [ "port", "d0/d25/classcom_1_1objectforge_1_1mascot_1_1_i_d_a_1_1telnet_1_1_client_descriptor.html#a00e9d6f7cef537bf9e47ba34d6460836", null ],
    [ "que", "d0/d25/classcom_1_1objectforge_1_1mascot_1_1_i_d_a_1_1telnet_1_1_client_descriptor.html#aa5c0e1dd42182951813d2ea0d2e497ad", null ],
    [ "socket", "d0/d25/classcom_1_1objectforge_1_1mascot_1_1_i_d_a_1_1telnet_1_1_client_descriptor.html#aff640cbfba55a8095332feb2bd625daa", null ]
];