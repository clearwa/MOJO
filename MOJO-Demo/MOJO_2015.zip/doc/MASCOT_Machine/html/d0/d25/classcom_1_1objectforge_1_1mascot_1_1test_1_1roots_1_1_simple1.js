var classcom_1_1objectforge_1_1mascot_1_1test_1_1roots_1_1_simple1 =
[
    [ "mascotRoot", "d0/d25/classcom_1_1objectforge_1_1mascot_1_1test_1_1roots_1_1_simple1.html#ae0b056eadd3f90b35b33457ca3568985", null ],
    [ "resumeRoot", "d0/d25/classcom_1_1objectforge_1_1mascot_1_1test_1_1roots_1_1_simple1.html#a8d0c0b175e3c53640446944a9536ca91", null ]
];