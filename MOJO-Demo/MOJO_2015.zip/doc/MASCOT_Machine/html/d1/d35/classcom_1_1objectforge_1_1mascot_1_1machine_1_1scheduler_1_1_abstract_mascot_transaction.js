var classcom_1_1objectforge_1_1mascot_1_1machine_1_1scheduler_1_1_abstract_mascot_transaction =
[
    [ "AbstractMascotTransaction", "d1/d35/classcom_1_1objectforge_1_1mascot_1_1machine_1_1scheduler_1_1_abstract_mascot_transaction.html#ad75c38c0a8d34a4f631e3092476f6e7e", null ]
];