var classcom_1_1objectforge_1_1mascot_1_1utility_1_1_mascot_runtime_exception =
[
    [ "MascotRuntimeException", "d1/d3a/classcom_1_1objectforge_1_1mascot_1_1utility_1_1_mascot_runtime_exception.html#a38a839cb6d092680b275e716a62bf354", null ],
    [ "MascotRuntimeException", "d1/d3a/classcom_1_1objectforge_1_1mascot_1_1utility_1_1_mascot_runtime_exception.html#a5f78080de38cf882d52e63bfe40383a9", null ]
];