var classcom_1_1objectforge_1_1mascot_1_1machine_1_1model_1_1_device_entity_1_1_device_ref =
[
    [ "DeviceRef", "d1/dcf/classcom_1_1objectforge_1_1mascot_1_1machine_1_1model_1_1_device_entity_1_1_device_ref.html#a90f2d81a8e648bd6bfbb0f8a67d8d126", null ],
    [ "getIncarnation", "d1/dcf/classcom_1_1objectforge_1_1mascot_1_1machine_1_1model_1_1_device_entity_1_1_device_ref.html#ac7c03f286a1c1cad1af2ba5c85164b89", null ],
    [ "getInstance", "d1/dcf/classcom_1_1objectforge_1_1mascot_1_1machine_1_1model_1_1_device_entity_1_1_device_ref.html#ac7e1bec8e7d2bb08bce27977dee36ae8", null ],
    [ "getReference", "d1/dcf/classcom_1_1objectforge_1_1mascot_1_1machine_1_1model_1_1_device_entity_1_1_device_ref.html#a9d2a62744ef3f854e20a77fe060e9984", null ],
    [ "getReftype", "d1/dcf/classcom_1_1objectforge_1_1mascot_1_1machine_1_1model_1_1_device_entity_1_1_device_ref.html#a33c32d93f99b4bbad467b813c49644b3", null ]
];