var namespacecom_1_1objectforge_1_1mascot_1_1machine_1_1roots =
[
    [ "AbstractRoot", "d7/d80/classcom_1_1objectforge_1_1mascot_1_1machine_1_1roots_1_1_abstract_root.html", "d7/d80/classcom_1_1objectforge_1_1mascot_1_1machine_1_1roots_1_1_abstract_root" ],
    [ "RootStub", "dc/d41/classcom_1_1objectforge_1_1mascot_1_1machine_1_1roots_1_1_root_stub.html", "dc/d41/classcom_1_1objectforge_1_1mascot_1_1machine_1_1roots_1_1_root_stub" ]
];