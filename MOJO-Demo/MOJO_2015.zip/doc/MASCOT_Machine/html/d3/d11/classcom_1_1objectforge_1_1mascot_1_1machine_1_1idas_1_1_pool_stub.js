var classcom_1_1objectforge_1_1mascot_1_1machine_1_1idas_1_1_pool_stub =
[
    [ "read", "d3/d11/classcom_1_1objectforge_1_1mascot_1_1machine_1_1idas_1_1_pool_stub.html#a98614baa89b6919dac0ac2e54df160e6", null ],
    [ "status", "d3/d11/classcom_1_1objectforge_1_1mascot_1_1machine_1_1idas_1_1_pool_stub.html#a6e8bee9607a49de251a07b713fc41f50", null ],
    [ "write", "d3/d11/classcom_1_1objectforge_1_1mascot_1_1machine_1_1idas_1_1_pool_stub.html#aa93c2cf321c1ede700fd8e4ae8652aca", null ]
];