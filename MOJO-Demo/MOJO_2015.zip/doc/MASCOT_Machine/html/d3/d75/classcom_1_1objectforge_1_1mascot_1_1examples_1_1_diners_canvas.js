var classcom_1_1objectforge_1_1mascot_1_1examples_1_1_diners_canvas =
[
    [ "DinersCanvas", "d3/d75/classcom_1_1objectforge_1_1mascot_1_1examples_1_1_diners_canvas.html#a065898415de9a2f07ed3a35a3c95a2bf", null ],
    [ "backdrop", "d3/d75/classcom_1_1objectforge_1_1mascot_1_1examples_1_1_diners_canvas.html#aef847dbbc7fe1774cc4eed8b1f78ad27", null ],
    [ "createImageBytes", "d3/d75/classcom_1_1objectforge_1_1mascot_1_1examples_1_1_diners_canvas.html#a0ec999bacc862fbee9771c1f19cfcc0e", null ],
    [ "paint", "d3/d75/classcom_1_1objectforge_1_1mascot_1_1examples_1_1_diners_canvas.html#a6ac9a55d01179f4ea23f394456918330", null ],
    [ "setFork", "d3/d75/classcom_1_1objectforge_1_1mascot_1_1examples_1_1_diners_canvas.html#a8a9f59bb4f6aa30b4f689b8e86033a46", null ],
    [ "setPhil", "d3/d75/classcom_1_1objectforge_1_1mascot_1_1examples_1_1_diners_canvas.html#a3379d5862dd03f1bd45b157def9a0489", null ],
    [ "update", "d3/d75/classcom_1_1objectforge_1_1mascot_1_1examples_1_1_diners_canvas.html#ab2cc6a1b3c28da87ac82e6291ba7a055", null ],
    [ "EAT", "d3/d75/classcom_1_1objectforge_1_1mascot_1_1examples_1_1_diners_canvas.html#a5e26978681298c79d79af08b3aac9591", null ],
    [ "HUNGRY", "d3/d75/classcom_1_1objectforge_1_1mascot_1_1examples_1_1_diners_canvas.html#aebba01f187a10fee37817c0df8250567", null ],
    [ "LEFT", "d3/d75/classcom_1_1objectforge_1_1mascot_1_1examples_1_1_diners_canvas.html#ab77f97b3362d76a18f767760d574a610", null ],
    [ "RIGHT", "d3/d75/classcom_1_1objectforge_1_1mascot_1_1examples_1_1_diners_canvas.html#a49376b6ba3adf921a80cfa00629a2d04", null ],
    [ "SLEEP", "d3/d75/classcom_1_1objectforge_1_1mascot_1_1examples_1_1_diners_canvas.html#a53c9c176730be15bc8436b500a0f79c3", null ]
];