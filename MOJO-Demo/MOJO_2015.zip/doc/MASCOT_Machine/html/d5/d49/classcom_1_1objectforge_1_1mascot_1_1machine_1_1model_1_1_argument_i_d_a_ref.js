var classcom_1_1objectforge_1_1mascot_1_1machine_1_1model_1_1_argument_i_d_a_ref =
[
    [ "ArgumentIDARef", "d5/d49/classcom_1_1objectforge_1_1mascot_1_1machine_1_1model_1_1_argument_i_d_a_ref.html#a5196010b3b1c61b59cc9a7dfc7dda86d", null ],
    [ "getIncarnation", "d5/d49/classcom_1_1objectforge_1_1mascot_1_1machine_1_1model_1_1_argument_i_d_a_ref.html#a4f071ec0244404dab500cc0890acc9bf", null ],
    [ "getInstance", "d5/d49/classcom_1_1objectforge_1_1mascot_1_1machine_1_1model_1_1_argument_i_d_a_ref.html#a73610465c1a3e3597f186b8f542bca32", null ],
    [ "getReference", "d5/d49/classcom_1_1objectforge_1_1mascot_1_1machine_1_1model_1_1_argument_i_d_a_ref.html#aae6c2cccebac5e0d896a435f1036a6a1", null ],
    [ "getReftype", "d5/d49/classcom_1_1objectforge_1_1mascot_1_1machine_1_1model_1_1_argument_i_d_a_ref.html#a232242b007fe9901973cdde5b6826d5f", null ]
];