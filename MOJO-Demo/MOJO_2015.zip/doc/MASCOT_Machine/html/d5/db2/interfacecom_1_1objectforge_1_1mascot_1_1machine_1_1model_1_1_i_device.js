var interfacecom_1_1objectforge_1_1mascot_1_1machine_1_1model_1_1_i_device =
[
    [ "add", "d5/db2/interfacecom_1_1objectforge_1_1mascot_1_1machine_1_1model_1_1_i_device.html#a812f6467019fe176debef56308b6cee9", null ],
    [ "close", "d5/db2/interfacecom_1_1objectforge_1_1mascot_1_1machine_1_1model_1_1_i_device.html#a8db54e8d9270d47aa0ec4d79a48ac811", null ],
    [ "open", "d5/db2/interfacecom_1_1objectforge_1_1mascot_1_1machine_1_1model_1_1_i_device.html#af8ab8c4d45ff72807b47b3eb1c897466", null ],
    [ "status", "d5/db2/interfacecom_1_1objectforge_1_1mascot_1_1machine_1_1model_1_1_i_device.html#a5531302f0d96e50325aed4e7ca11c100", null ]
];