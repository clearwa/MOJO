var classcom_1_1objectforge_1_1mascot_1_1machine_1_1device_1_1_device_control =
[
    [ "DeviceControl", "d5/dc6/classcom_1_1objectforge_1_1mascot_1_1machine_1_1device_1_1_device_control.html#aa56d412011e00a30932d6ab746cc026f", null ],
    [ "payload", "d5/dc6/classcom_1_1objectforge_1_1mascot_1_1machine_1_1device_1_1_device_control.html#a092709cb706805dcbc2d9304611072c6", null ]
];