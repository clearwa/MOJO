var classcom_1_1objectforge_1_1mascot_1_1samples_1_1_diners_display_1_1_w_adapter =
[
    [ "windowClosed", "d5/d37/classcom_1_1objectforge_1_1mascot_1_1samples_1_1_diners_display_1_1_w_adapter.html#aac087abd1066bd0df08dd5a5fba257d6", null ],
    [ "windowClosing", "d5/d37/classcom_1_1objectforge_1_1mascot_1_1samples_1_1_diners_display_1_1_w_adapter.html#abff7d692fc19724a288b58d731110ef0", null ]
];