var classcom_1_1objectforge_1_1mascot_1_1machine_1_1estore_1_1_es_device_i_d_a_ref =
[
    [ "EsDeviceIDARef", "d5/d1e/classcom_1_1objectforge_1_1mascot_1_1machine_1_1estore_1_1_es_device_i_d_a_ref.html#a685dc6cea5053f58bb7f5983d48367bf", null ],
    [ "EsDeviceIDARef", "d5/d1e/classcom_1_1objectforge_1_1mascot_1_1machine_1_1estore_1_1_es_device_i_d_a_ref.html#a88072095e9502da599e19933fe1931a5", null ],
    [ "getInstance", "d5/d1e/classcom_1_1objectforge_1_1mascot_1_1machine_1_1estore_1_1_es_device_i_d_a_ref.html#a3dc3033044a14832c7e3933484699380", null ]
];