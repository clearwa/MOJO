var classcom_1_1objectforge_1_1mascot_1_1_i_d_a_1_1monitor_1_1_monitor_device_1_1_monitor_reader_private =
[
    [ "mascotRoot", "d2/d55/classcom_1_1objectforge_1_1mascot_1_1_i_d_a_1_1monitor_1_1_monitor_device_1_1_monitor_reader_private.html#a5c3b78cefb763efeb65be478563725dc", null ],
    [ "resumeRoot", "d2/d55/classcom_1_1objectforge_1_1mascot_1_1_i_d_a_1_1monitor_1_1_monitor_device_1_1_monitor_reader_private.html#a6564d5b9cb0b6cb78ed9f9509c5b7930", null ]
];