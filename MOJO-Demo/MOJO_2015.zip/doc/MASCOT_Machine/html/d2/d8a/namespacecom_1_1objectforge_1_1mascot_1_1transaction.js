var namespacecom_1_1objectforge_1_1mascot_1_1transaction =
[
    [ "MascotTransaction", "da/d24/classcom_1_1objectforge_1_1mascot_1_1transaction_1_1_mascot_transaction.html", "da/d24/classcom_1_1objectforge_1_1mascot_1_1transaction_1_1_mascot_transaction" ],
    [ "SimpleRoot", "dd/d3a/classcom_1_1objectforge_1_1mascot_1_1transaction_1_1_simple_root.html", "dd/d3a/classcom_1_1objectforge_1_1mascot_1_1transaction_1_1_simple_root" ]
];