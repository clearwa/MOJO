var namespacecom_1_1objectforge_1_1mascot_1_1machine_1_1device =
[
    [ "Device", "d9/d47/classcom_1_1objectforge_1_1mascot_1_1machine_1_1device_1_1_device.html", "d9/d47/classcom_1_1objectforge_1_1mascot_1_1machine_1_1device_1_1_device" ],
    [ "DeviceControl", "d5/dc6/classcom_1_1objectforge_1_1mascot_1_1machine_1_1device_1_1_device_control.html", "d5/dc6/classcom_1_1objectforge_1_1mascot_1_1machine_1_1device_1_1_device_control" ],
    [ "DevicePool", "df/dc5/classcom_1_1objectforge_1_1mascot_1_1machine_1_1device_1_1_device_pool.html", "df/dc5/classcom_1_1objectforge_1_1mascot_1_1machine_1_1device_1_1_device_pool" ]
];