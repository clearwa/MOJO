var annotated =
[
    [ "com", "d8/dee/namespacecom.html", "d8/dee/namespacecom" ],
    [ "mascot", "d4/d64/namespacemascot.html", "d4/d64/namespacemascot" ]
];