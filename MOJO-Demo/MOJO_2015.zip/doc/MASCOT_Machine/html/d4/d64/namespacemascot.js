var namespacemascot =
[
    [ "test", "db/dc0/namespacemascot_1_1test.html", "db/dc0/namespacemascot_1_1test" ]
];