var classcom_1_1objectforge_1_1mascot_1_1_i_d_a_1_1monitor_1_1_monitor_device_1_1_monitor_writer_private =
[
    [ "mascotRoot", "d4/d59/classcom_1_1objectforge_1_1mascot_1_1_i_d_a_1_1monitor_1_1_monitor_device_1_1_monitor_writer_private.html#a266171dc32eae34465203a5d70a06e60", null ],
    [ "resumeRoot", "d4/d59/classcom_1_1objectforge_1_1mascot_1_1_i_d_a_1_1monitor_1_1_monitor_device_1_1_monitor_writer_private.html#a208777fa0865ee03ddc4afb2080842e0", null ]
];