var classcom_1_1objectforge_1_1mascot_1_1machine_1_1internal_1_1_boot_tester =
[
    [ "mascotRoot", "d4/d7f/classcom_1_1objectforge_1_1mascot_1_1machine_1_1internal_1_1_boot_tester.html#a04271d36e2d7c3ebf255706994a810cc", null ],
    [ "resumeRoot", "d4/d7f/classcom_1_1objectforge_1_1mascot_1_1machine_1_1internal_1_1_boot_tester.html#a5d09ad2f9c47a3438b94bfb9925804ab", null ]
];