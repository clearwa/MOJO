var classcom_1_1objectforge_1_1mascot_1_1machine_1_1model_1_1_channel_entity =
[
    [ "ChannelEntity", "d4/d50/classcom_1_1objectforge_1_1mascot_1_1machine_1_1model_1_1_channel_entity.html#a4d04daa61321f7c2920cfe60993faeac", null ],
    [ "getTypeID", "d4/d50/classcom_1_1objectforge_1_1mascot_1_1machine_1_1model_1_1_channel_entity.html#ab60e0832fa9b03e3663fbe95cf15d357", null ]
];