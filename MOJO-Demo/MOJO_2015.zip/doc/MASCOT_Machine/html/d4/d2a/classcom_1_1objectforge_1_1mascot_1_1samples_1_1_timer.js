var classcom_1_1objectforge_1_1mascot_1_1samples_1_1_timer =
[
    [ "mascotRoot", "d4/d2a/classcom_1_1objectforge_1_1mascot_1_1samples_1_1_timer.html#acfb7cdf90bae1947c602de9367dc1d51", null ],
    [ "resumeRoot", "d4/d2a/classcom_1_1objectforge_1_1mascot_1_1samples_1_1_timer.html#a15e16534ed90dd4d631c5cd70c2b34c0", null ]
];